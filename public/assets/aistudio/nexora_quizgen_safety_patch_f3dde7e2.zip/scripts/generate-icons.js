import fs from 'fs';
import path from 'path';
import sharp from 'sharp';

const publicDir = path.resolve('public');
if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}

// Full-bleed SVG with dark midnight-blue background and glowing NEXORA crest
const svgIcon = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">
  <defs>
    <linearGradient id="bgGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stopColor="#040816"/>
      <stop offset="50%" stopColor="#081432"/>
      <stop offset="100%" stopColor="#0a1a3f"/>
    </linearGradient>
    <linearGradient id="nexGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stopColor="#00f0ff"/>
      <stop offset="45%" stopColor="#0088ff"/>
      <stop offset="100%" stopColor="#8b5cf6"/>
    </linearGradient>
    <radialGradient id="reactorCore" cx="50%" cy="50%" r="50%">
      <stop offset="0%" stopColor="#ffffff" stop-opacity="1"/>
      <stop offset="30%" stopColor="#00f0ff" stop-opacity="0.8"/>
      <stop offset="70%" stopColor="#0077fe" stop-opacity="0.2"/>
      <stop offset="100%" stopColor="#0044aa" stop-opacity="0"/>
    </radialGradient>
    <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
      <feGaussianBlur stdDeviation="12" result="blur"/>
      <feComposite in="SourceGraphic" in2="blur" operator="over"/>
    </filter>
  </defs>

  <!-- Solid background -->
  <rect width="512" height="512" rx="100" fill="url(#bgGrad)"/>
  
  <!-- Outer border rim -->
  <rect x="8" y="8" width="496" height="496" rx="92" fill="none" stroke="#00f0ff" stroke-opacity="0.3" stroke-width="4"/>

  <!-- Subtle grid lines -->
  <line x1="256" y1="20" x2="256" y2="492" stroke="#00f0ff" stroke-opacity="0.1" stroke-width="2" stroke-dasharray="8 8"/>
  <line x1="20" y1="256" x2="492" y2="256" stroke="#00f0ff" stroke-opacity="0.1" stroke-width="2" stroke-dasharray="8 8"/>

  <!-- Centered NEXORA Logo Crest (scales 100 -> 340) -->
  <g transform="translate(86, 86) scale(3.4)" filter="url(#glow)">
    <!-- Hexagonal Outer Shield -->
    <polygon points="50,6 88,28 88,72 50,94 12,72 12,28" stroke="url(#nexGrad)" stroke-width="4" stroke-linejoin="round" fill="rgba(6, 22, 54, 0.7)"/>

    <!-- Arc Reactor Concentric Ring -->
    <circle cx="50" cy="50" r="30" stroke="rgba(0, 240, 255, 0.4)" stroke-width="1.8" stroke-dasharray="5 3"/>

    <!-- Stylized 'N' Core -->
    <path d="M34,68 L34,32 L44,32 L60,56 L60,32 L68,32 L68,68 L58,68 L42,44 L42,68 Z" fill="url(#nexGrad)"/>

    <!-- Core Reactor Glow & Quantum Flare -->
    <circle cx="50" cy="50" r="7" fill="url(#reactorCore)"/>
    <circle cx="50" cy="50" r="3" fill="#ffffff"/>

    <!-- Tech Nodes -->
    <circle cx="50" cy="6" r="2.5" fill="#00f0ff"/>
    <circle cx="88" cy="28" r="2.5" fill="#00f0ff"/>
    <circle cx="88" cy="72" r="2.5" fill="#8b5cf6"/>
    <circle cx="50" cy="94" r="2.5" fill="#8b5cf6"/>
    <circle cx="12" cy="72" r="2.5" fill="#0088ff"/>
    <circle cx="12" cy="28" r="2.5" fill="#00f0ff"/>
  </g>
</svg>`;

// Maskable icon with 20% safe zone margin
const svgMaskable = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">
  <defs>
    <linearGradient id="bgGradM" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stopColor="#040816"/>
      <stop offset="50%" stopColor="#081432"/>
      <stop offset="100%" stopColor="#0a1a3f"/>
    </linearGradient>
    <linearGradient id="nexGradM" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stopColor="#00f0ff"/>
      <stop offset="45%" stopColor="#0088ff"/>
      <stop offset="100%" stopColor="#8b5cf6"/>
    </linearGradient>
    <radialGradient id="reactorCoreM" cx="50%" cy="50%" r="50%">
      <stop offset="0%" stopColor="#ffffff" stop-opacity="1"/>
      <stop offset="30%" stopColor="#00f0ff" stop-opacity="0.8"/>
      <stop offset="70%" stopColor="#0077fe" stop-opacity="0.2"/>
      <stop offset="100%" stopColor="#0044aa" stop-opacity="0"/>
    </radialGradient>
    <filter id="glowM" x="-20%" y="-20%" width="140%" height="140%">
      <feGaussianBlur stdDeviation="10" result="blur"/>
      <feComposite in="SourceGraphic" in2="blur" operator="over"/>
    </filter>
  </defs>

  <!-- Full-bleed background for maskable cropping -->
  <rect width="512" height="512" fill="url(#bgGradM)"/>

  <!-- Centered within 75% safe area (scale 2.7) -->
  <g transform="translate(121, 121) scale(2.7)" filter="url(#glowM)">
    <polygon points="50,6 88,28 88,72 50,94 12,72 12,28" stroke="url(#nexGradM)" stroke-width="4" stroke-linejoin="round" fill="rgba(6, 22, 54, 0.75)"/>
    <circle cx="50" cy="50" r="30" stroke="rgba(0, 240, 255, 0.4)" stroke-width="1.8" stroke-dasharray="5 3"/>
    <path d="M34,68 L34,32 L44,32 L60,56 L60,32 L68,32 L68,68 L58,68 L42,44 L42,68 Z" fill="url(#nexGradM)"/>
    <circle cx="50" cy="50" r="7" fill="url(#reactorCoreM)"/>
    <circle cx="50" cy="50" r="3" fill="#ffffff"/>
  </g>
</svg>`;

async function run() {
  fs.writeFileSync(path.join(publicDir, 'icon.svg'), svgIcon);
  fs.writeFileSync(path.join(publicDir, 'icon-maskable.svg'), svgMaskable);

  // Generate 512x512
  await sharp(Buffer.from(svgIcon))
    .resize(512, 512)
    .png()
    .toFile(path.join(publicDir, 'pwa-512x512.png'));

  // Generate 192x192
  await sharp(Buffer.from(svgIcon))
    .resize(192, 192)
    .png()
    .toFile(path.join(publicDir, 'pwa-192x192.png'));

  // Generate Maskable 512x512
  await sharp(Buffer.from(svgMaskable))
    .resize(512, 512)
    .png()
    .toFile(path.join(publicDir, 'pwa-maskable-512x512.png'));

  // Generate Apple Touch Icon (180x180)
  await sharp(Buffer.from(svgIcon))
    .resize(180, 180)
    .png()
    .toFile(path.join(publicDir, 'apple-touch-icon.png'));

  // Generate favicon 64x64 PNG
  await sharp(Buffer.from(svgIcon))
    .resize(64, 64)
    .png()
    .toFile(path.join(publicDir, 'favicon.ico'));

  console.log('Successfully generated all PWA icons in /public!');
}

run().catch(console.error);
